import React from "react";
import { StatusBar } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createStackNavigator } from "@react-navigation/stack";
import List from "@screens/List";
import Info from "@screens/Info";

const RootStack = createStackNavigator();
const Tabs = createBottomTabNavigator();

const TabsNavigation = () => (
    <Tabs.Navigator
        initialRouteName="Main"
        tabBarOptions={{
            activeBackgroundColor: "#fff",
            inactiveBackgroundColor: "#fff",
            showLabel: true,
            showIcon: true,
            activeTintColor: "green",
            inactiveTintColor: "#828282",
        }}
        tabStyle={{
            flexDirection: "row",
        }}
    >
        <Tabs.Screen
            name="Main"
            component={List}
            options={{
                title: "Moods",
            }}
            listeners={({ navigation }) => ({
                tabPress: () => {
                    navigation.navigate("Main");
                },
            })}
        />
        <Tabs.Screen
            name="Info"
            component={Info}
            options={{
                title: "Info",
            }}
            listeners={({ navigation }) => ({
                tabPress: () => {
                    navigation.navigate("Info");
                },
            })}
        />
    </Tabs.Navigator>
);

const MainNavigation = () => (
    <NavigationContainer>
        <StatusBar
            hidden={false}
            backgroundColor="transparent"
            barStyle="dark-content"
        />
        <RootStack.Navigator initialRouteName="MainStackScreen">
            <RootStack.Screen
                name="Main"
                component={TabsNavigation}
                options={{ headerShown: false }}
            />
        </RootStack.Navigator>
    </NavigationContainer>
);

export default MainNavigation;