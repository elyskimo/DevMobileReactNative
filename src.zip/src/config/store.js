export default MOODS = [
    {id:1,mood:5,title:"Parfait"},
    // {id:2,mood:4,title:"Bien"},
    // {id:3,mood:3,title:"Normal"},
    // {id:4,mood:2,title:"Pas bien"},
    // {id:5,mood:1,title:"Mal"},
];
