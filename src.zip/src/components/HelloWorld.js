import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

export default function HelloWorld() {
    return (
        <View>
            <Text style={styles.text}>Hello world</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    text: {
        color: 'red',
        marginTop: 20,
        fontSize: 20,
        fontFamily: 'Arial',
        alignItems: 'center',
        justifyContent: 'center',
    },
});